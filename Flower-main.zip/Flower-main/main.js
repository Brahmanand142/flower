 
onload = () => {
  const c = setTimeout(() => {
    document.body.classList.remove("not-loaded");
    clearTimeout(c);
  }, 1000);
};

window.addEventListener('DOMContentLoaded', () => {
  const flowerTexts = document.querySelectorAll('.flower-text');
  flowerTexts.forEach((flowerText) => {
    // Trigger typing effect for each flower's text element
    flowerText.style.animation = 'none'; // Reset animation
    flowerText.offsetHeight; // Trigger reflow
    flowerText.style.animation = 'typing 3s steps(' + flowerText.textContent.length + ') 1s forwards, blink 0.75s step-end infinite'; // Apply typing animation
  });
});
